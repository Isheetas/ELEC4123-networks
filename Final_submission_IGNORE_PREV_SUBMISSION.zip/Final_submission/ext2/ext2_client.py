#client for extension task 1
import socket
import time
from ext2_utility import *





def get_plaintext(HOST, PORT):
    '''
    public and private keys
    '''
    #client sends 'n,e'
    n = '252837207378338387332619197259204540353'
    d = '48393883292703003300067554859838128129'
    e = '65537'



    '''
    1. Request data from client
    '''
    request = n + ',' + e
    request_bytes = bytes(request, 'utf-8')
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        print("Socket successfully created")
    except socket.error as err:
        print("socket creation failed with error %s" % (err))

    s.connect((HOST, PORT))
    s.send(request_bytes)
    data = s.recv(1024)
    s.close()
    #print('Received', data)
    '''
    Decrypt recieved data
    '''
    plaintext = decrypt_rsa(data, n, d)
    return plaintext



def main():

    '''
    local server details
    '''    
    HOST = '127.0.0.1'
    PORT = 3000
    PORT_marking = 12002

    plaintext = get_plaintext(HOST, PORT)
    print("dec:", plaintext)



    try:
        s_send = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        print("Socket successfully created to target server")
    except socket.error as err:
        print("socket creation failed with error %s to noise server" % (err))

    s_send.connect((HOST, PORT_marking))
    s_send.send(plaintext)
    s_send.close()
                
        #print_to_ascii(bits_to_bytes(bin))



    

    #display data
    #print_to_ascii(plaintext)


if __name__ == '__main__':
    start_time = time.time()
    i = 0
    while i < 1000:
        main()
        i += 1
    print("--- %s seconds ---" % (time.time() - start_time)) # run time check
 
